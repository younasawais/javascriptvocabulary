<?php
/************ Initialize *********************/
ob_start();
include 'includes/classes.php';
session_start ();
include 'includes/initializeGrammar.php';

checkWordListAvailable (); // Redirect to dashboard if no wordList
startNext ();
submitAnswer ();
goback ();
restart ();
submitRange ();

$_SESSION['wordList']->initiateCyclus (); // Initiate visibility values according to grammarStatus

?>
<!DOCTYPE html>
<head>
<link rel="stylesheet" type="text/css" href="css/grammar.css">
<title>Grammar Exercise</title>
</head>
<body>
	<div class="greyOutSide">
		<div class="dashboard">
			<p>GRAMMAR TRAINING</p>
		</div>
		<!--  FIRST SECTION -->
		<div class="first">
			<div class="left">
				<p>
					WORD : <span> <?php echo $_SESSION['wordListFiltered']->translations() ?></span>
				</p>
			</div>
			<div class="right">
				<p>
					NR : <span><?php echo ($_SESSION["currentNumber"]+1)?></span>
				</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<!--  SECOND SECTION -->
		<div class="second">
			<form action="grammar.php" method="post">
				<br> 
				<label>TRANSLATION :</label> <input class="answer" type="text" name="answer"> 
				<input class="submit" type="submit" value="Submit" name="submitAnswer"
					<?php echo $_SESSION['visibility']->submitWordButton() ?>>
			</form>
		</div>
		<!--  THIRD SECTION -->
		<div class="third">
			<div class="third-one">
				<div class="third-one-left">
					<table>
						<tr>
							<td>TOTAL WORDS :</td>
							<td><?php echo $_SESSION['words'];?></td>
						</tr>
						<tr>
							<td>AFTER FILTER:</td>
							<td><?php echo $_SESSION["wordList"]->totalWordsFiltered();?></td>
						</tr>
						<tr>
							<td>LIBRARY :</td>
							<td><?php echo $_SESSION['library'];?></td>
						</tr>
						<form action="grammar.php" method="post">
							<tr>
								<td>CATEGORY :</td>
								<td><select class="dropdown" name="dropdown">
									<?php categorySelection(); ?>
								</select></td>
							</tr>
							<tr>
								<td><input class="submitCategory" type="submit"
									value="Submit Cat." name="submitCategory"
									<?php echo $_SESSION['visibility']->submitCategoryButton() ?>>
								</td>
								<td><?php echo submitCategory();?></td>
							</tr>
						</form>
						<form action="grammar.php" method="post">
							<tr>
								<td>START RANGE :</td>
								<td><input class="startRange" type="number" name="startRange"></td>
							</tr>
							<tr>
								<td>END RANGE :</td>
								<td><input class="endRange" type="number" name="endRange"></td>
							</tr>
							<tr>
								<td><input class="submitRange" type="submit"
									value="Submit Range" name="submitRange"
									<?php echo $_SESSION['visibility']->submitRangeButton() ?>></td>
								<td><?php echo "Range : ". $_SESSION['wordListFiltered']->startRange . " - ". $_SESSION['wordListFiltered']->endRange?></td>
							</tr>
						</form>
						<tr>
							<td>CORRECT :</td>
							<td><?php echo $_SESSION['wordListFiltered']->totalRight() ?></td>
						</tr>
						<tr>
							<td>INCORRECT :</td>
							<td><?php echo $_SESSION['wordListFiltered']->totalWrong() ?></td>
						</tr>
						<tr>
							<td>TRIES LEFT :</td>
							<td><?php echo $_SESSION['wordListFiltered']->triesLeft() ?></td>
						</tr>
						<form action="grammar.php" method="post">
							<tr>
								<td><input class="showHint" type="submit" name="showHint"
									value="SHOW HINT"
									<?php echo $_SESSION['visibility']->showHintButton() ?>></td>
								<td><?php echo showHint() ?></td>
							</tr>
						</form>
					</table>
				</div>
				<div class="third-one-right">
					<p><?php echo $_SESSION["visibility"]->showBar()['valueLine1']?></p>
					<p><?php echo $_SESSION["visibility"]->showBar()['valueLine2']?></p>
					<?php 
					if ($_SESSION['visibility']->bar['FontSizeLine3']<>"" && isset($_SESSION['visibility']->bar['FontSizeLine3'])) {?>
						<p <?php echo $_SESSION['visibility']->showBar()['FontSizeLine3']?> ><?php echo "EXAMPLE: ".$_SESSION["visibility"]->showBar()['valueLine3']?></p>
					<?php 
					}else{
					?>
					<p><?php echo $_SESSION["visibility"]->showBar()['valueLine3']?></p>
					<?php 
					}
					?>
					
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
			<div class="third-two">
				<form action="grammar.php" method="POST">
					<br> <input value="GO BACK" class="exit" name="exit" type="submit">
					<input
						value="<?php echo $_SESSION['visibility']->startNextButton['value'] ?>"
						class="next" name="startNext" type="submit"> <input
						value="RESTART" class="restart" name="restart" type="submit">
				</form>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</body>
</html>

<?php
/* +++++++++++++++++++++++++++++++++++++++++++ SUBMIT BUTTONS +++++++++++++++++++++++++++++++++++++++++++++ */
function submitAnswer() {
	if (isset ( $_POST['submitAnswer'] ) && $_SESSION["grammarStatus"] == 'submitWord') {		// after button (( SUBMIT WORD ))
		
		$inputUser = strtoupper($_POST['answer']);
		$currentNumber = $_SESSION["currentNumber"];
		
		if ($inputUser == strtoupper($_SESSION["wordListFiltered"]->word[$currentNumber])) {		 // If right answer
			$_SESSION["wordListFiltered"]->totalRight++;
			$_SESSION["grammarStatus"] = 'nextWord';
			$_SESSION["wordListFiltered"]->triesLeft--;
			$_SESSION['visibility']->bar ['valueLine1'] = "";
			$_SESSION['visibility']->bar ['valueLine2'] = "CORRECT";
			$_SESSION['visibility']->bar ['valueLine3'] = " ". $_SESSION['wordListFiltered']->example[$currentNumber]." ";
			$_SESSION['visibility']->bar ['FontSizeLine3'] = 30;
			$_SESSION["wordListFiltered"]->hint	= 0;
		}else{																			 // If wrong answer
			if ($_SESSION["wordListFiltered"]->triesLeft > 1) {			// tries left
				$_SESSION["wordListFiltered"]->triesLeft--;
				$_SESSION['visibility']->bar ['valueLine1'] = "";
				$_SESSION['visibility']->bar ['valueLine2'] = "TRIES LEFT : " .$_SESSION["wordListFiltered"]->triesLeft;
				$_SESSION['visibility']->bar ['valueLine3'] = ""; 
			}else{														// no tries left
				$_SESSION['visibility']->bar ['valueLine1'] = "CORRECT ANSWER IS";
				$_SESSION['visibility']->bar ['valueLine2'] = " ". $_SESSION['wordListFiltered']->word[$currentNumber]." ";
				$_SESSION['visibility']->bar ['valueLine3'] = " ". $_SESSION['wordListFiltered']->example[$currentNumber]." "; 
				$_SESSION['visibility']->bar ['FontSizeLine3'] = 30;
				$_SESSION["wordListFiltered"]->totalWrong++;
				$_SESSION["wordListFiltered"]->triesLeft--;
				$_SESSION["grammarStatus"] 			= 'nextWord';
				$_SESSION["wordListFiltered"]->hint	= 0;
			}
		}
	}
}

/******************** Start/Nect Button ***************************/
function startNext() {

	if (isset ( $_POST['startNext'] ) && $_SESSION["grammarStatus"] == 'stopped') { 	 	 		// after button (( START ))
		$_SESSION['wordListFiltered']->setFilteredList (); // setup filtered list
		$_SESSION["grammarStatus"] = 'submitWord';
		$_SESSION['visibility']->bar ['valueLine1'] = "";
		$_SESSION['visibility']->bar ['valueLine2'] = "GIVE IN THE TRANSLATION PLEASE";
		$_SESSION['visibility']->bar ['valueLine3'] = ""; 
		
		if ($_SESSION["wordListFiltered"]->totalWords () >= $_SESSION["currentNumber"]) {
			$_SESSION["currentNumber"]++;
		}
	}else if (isset ( $_POST['startNext'] ) && $_SESSION["grammarStatus"] == 'nextWord'){			// after button (( NEXT ))
		$_SESSION["grammarStatus"] = 'submitWord';
		$_SESSION["wordListFiltered"]->triesLeft = 3;
		$_SESSION["currentNumber"]++;
		$_SESSION['visibility']->bar ['valueLine1']			 = "";
		$_SESSION['visibility']->bar ['valueLine2']			 = "GIVE IN THE TRANSLATION PLEASE";
		$_SESSION['visibility']->bar ['valueLine3'] 		 = ""; 
		$_SESSION['visibility']->bar ['FontSizeLine3']		 = "";
		if (!isset($_SESSION["wordListFiltered"]->word[$_SESSION["currentNumber"]])) {
			$_SESSION['visibility']->bar ['valueLine1']		 ="WRONG : ". $_SESSION["wordListFiltered"]->totalWrong;
			$_SESSION['visibility']->bar ['valueLine2'] 	 ="RIGHT : ". $_SESSION["wordListFiltered"]->totalRight;
			$_SESSION['visibility']->bar ['valueLine3']		 = "PRESS RESTART OR CHANGE RANGE & CATEGORY"; 
			$_SESSION["grammarStatus"] = 'finished';
			$_SESSION["currentNumber"] = -1;
		}

	}else if (isset ( $_POST['startNext'] ) && $_SESSION["grammarStatus"] == 'finished'){			// after button (( FINISHED ))
		$_SESSION['visibility']->bar ['valueLine1']		 = "";
		$_SESSION['visibility']->bar ['valueLine2']		 = "GIVE IN THE TRANSLATION PLEASE";
		$_SESSION['visibility']->bar ['valueLine3']		 = "";
		$_SESSION['visibility']->bar ['FontSizeLine3']	 = "";
		$_SESSION["grammarStatus"] = 'submitWord';
		$_SESSION["wordListFiltered"]->triesLeft		 = 3;
		$_SESSION["currentNumber"]++;
		$_SESSION["wordListFiltered"]->totalRight		 = 0;
		$_SESSION["wordListFiltered"]->totalWrong		 = 0;
		
		$emptyArray = array();
		$_SESSION["wordListFiltered"]->word 			 = $emptyArray;
		$_SESSION["wordListFiltered"]->translate1		 = $emptyArray;
		$_SESSION["wordListFiltered"]->translate2 		 = $emptyArray;
		$_SESSION["wordListFiltered"]->synonym 			 = $emptyArray;
		$_SESSION["wordListFiltered"]->definition 		 = $emptyArray;
		$_SESSION["wordListFiltered"]->example 			 = $emptyArray;
		$_SESSION['wordListFiltered']->setFilteredList (); // setup filtered list
	}
}

function submitRange() {
	if (isset ( $_POST["submitRange"] )) {
		if (isset ( $_POST["startRange"] ) && isset ( $_POST["endRange"] ) && ! empty ( $_POST["startRange"] ) && ! empty ( $_POST["endRange"] )) {
			if ($_POST["startRange"] < $_POST["endRange"] && $_POST["endRange"] < ($_SESSION['words'] + 1)) {
				$_SESSION['wordListFiltered']->startRange = $_POST["startRange"];
				$_SESSION['wordListFiltered']->endRange = $_POST["endRange"];
				$_SESSION['visibility']->bar ['valueLine1'] = "";
				$_SESSION['visibility']->bar ['valueLine2'] = "RANGES APPLIED!";
				$_SESSION['visibility']->bar ['valueLine3'] = ""; 
			}else{
				$_SESSION['visibility']->bar ['valueLine1'] = "CHECK RANGES PLEASE!";
				$_SESSION['visibility']->bar ['valueLine2'] = "";
				$_SESSION['visibility']->bar ['valueLine3'] = ""; 
			}
		} else if($_POST["startRange"]){
			$_SESSION['visibility']->bar ['valueLine1'] = "Check ranges please";
		}
	}
}

/******************** Submit selected category ***************************/
function submitCategory() {
	if (isset ( $_POST['submitCategory'] )) {											// If category submitted
		$_SESSION['visibility']->bar ['valueLine1'] = "";
		$_SESSION['visibility']->bar ['valueLine2'] = "CATEGORY APPLIED";
		$_SESSION['visibility']->bar ['valueLine3'] = ""; 
		return $_SESSION['wordListFiltered']->categorySelected = $_POST['dropdown'];
	}else if(isset($_SESSION['wordListFiltered']->categorySelected)){					// If category already set
		return $_SESSION['wordListFiltered']->categorySelected;
	}else{
		return $_SESSION['wordListFiltered']->categorySelected = "ALL";
	}
}

function showHint() {
	if (isset ( $_POST['showHint'] ) && ($_SESSION["grammarStatus"] != 'stopped')) { 
		$hint = $_SESSION["wordListFiltered"]->hints ( "add" );
		$_SESSION['visibility']->bar ['valueLine1'] = "";
		$_SESSION['visibility']->bar ['valueLine2'] = "CHECK HINT";
		$_SESSION['visibility']->bar ['valueLine3'] = $hint; 
		return $hint;
	} else if (! isset ( $_POST['showHint'] ) && ($_SESSION["grammarStatus"] != 'stopped')) {
// 		$_SESSION['visibility']->bar ['valueLine1'] = "";
// 		$_SESSION['visibility']->bar ['valueLine2'] = "";
// 		$_SESSION['visibility']->bar ['valueLine3'] = ""; 
		return $_SESSION["wordListFiltered"]->hints ( "notAdd" );
	} else {
		return "";
	}
}

/*+++++++++++++++++++++++++++++++++++++++++++ END SUBMIT BUTTONS +++++++++++++++++++++++++++++++++++++++++++++ */
function categorySelection() {
	foreach ( $_SESSION['wordList']->categoryList as $i ) { // go through categoryList
		echo "<option value='$i'>{$i}</option>"; // echo every single category
	}
}

/*********** Check if library available, else redirict to dashboard *******************/
function checkWordListAvailable() {
	if (isset ( $_SESSION['wordList'] )) {
		$_SESSION['grammarStarted'] = 1;
	} else {
		header ( 'Location: index.php' ); // redirect to dashboard
	}
}
/******************** Go back to dashboard ***************************/
function goback() {
	if (isset ( $_POST['exit'] )) {
		$_SESSION['wordListFiltered']->startRange = 0;
		$_SESSION['wordListFiltered']->endRange = $_SESSION['words'];
		unset ( $_SESSION['grammarStarted'] );
		unset ( $_SESSION['grammarStatus'] );
		header ( 'Location: index.php' ); // redirect to dashboard
	}
}

/********************** Restart Session *****************************/
function restart() {
	if (isset ( $_POST['restart'] )) {
		$_SESSION["currentNumber"] = -1;
		$_SESSION['visibility']->bar ['valueLine1'] = "";
		$_SESSION['visibility']->bar ['valueLine2'] = "";
		$_SESSION['visibility']->bar ['valueLine3'] = "PRESS RESTART OR CHANGE RANGE & CATEGORY"; 
		$_SESSION['wordListFiltered']->startRange 	= 0;
		$_SESSION['wordListFiltered']->endRange		= $_SESSION['words'];
		unset ( $_SESSION['grammarStarted'] );
		$_SESSION["grammarStatus"] = 'stopped';
	}
}
?>