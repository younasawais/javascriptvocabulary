
document.onload = initialize();
var fullWordList; 
var filteredList;
var config;
var showHide;

function initialize(){
  fullWordList    = new wordList(); 
  filteredList    = new wordList();
  config          = new configuration();
  config.status   = "default";
  showHide        = new showHideContent();
  showHide.checkStatus();
}

/************** Button Start / Next  **********/
function startButton(){
  if(config.status == "default"){              // After default
    config.status         = "start";
    config.nr             = 0;
  } else if(config.status == "confirm"){       // After Confirm
    config.status         = "afterNext";
    config.nr++; 
    config.triesLeft      = 3;
  } else if(config.status == "finished"){      // After Confirm
    config.status         = "default";
    config.nr             = 0; 
    config.triesLeft      = 3;
  }
  
  config.givenWord        = 
        filteredList.translation1[config.nr] + " : " + 
        filteredList.translation2[config.nr]; 
  config.comment          = 'Defenition : <span class="yellow">'  + filteredList.definition1[config.nr] + 
                                      "</span> <br>Give in the right answer please!";
  config.currentWord      = filteredList.word[config.nr];
  showHide.getInput().focus();
  showHide.getInput().select();
  showHide.checkStatus();
}

/************** Submit Button  **********/
function submitWordButton(){
  
  showHide.getInput().value       = showHide.getInput().value.toLowerCase();  //input to lowercase
  config.currentWord              = config.currentWord.toLowerCase();
  
  if( config.currentWord == showHide.getInput().value ){ // Right answer
    config.correct++;
    
    if( filteredList.word.length == config.nr ){
      config.status               = "finished";
    }else{
      config.status               = "confirm";
    }
    config.hintValue              = "";
    config.comment                = 'Correct! <br>Example: <span class="yellow"> ' +
                                    filteredList.example[config.nr];
  }else if(config.triesLeft === 1){   // Wrong answer & next try
    config.incorrect++;
    config.triesLeft--;
    if( filteredList.word.length == config.nr ){
      config.status               = "finished";
    }else{
      config.status               = "confirm";
    }
    config.hintValue              = "";
    config.comment                = "Correct answer is : " + config.currentWord + '! <br> Example: <span class="yellow">' +
                                    filteredList.example[config.nr];
  }else{                              // Wrong answer & No tries left
    config.triesLeft--;
    config.wrongAnswer            = true;
    config.comment                = "Incorrect! You have " + config.triesLeft + " left!";
  }
  showHide.checkStatus();
}

/************** Button Show Hint  **********/
function showHint(){
  if( config.hints < config.currentWord.length ){
    config.hints++;
    config.hintValue       =  '<br>Hints :<span class="green"> ' +
                    config.currentWord.substring( 0, config.hints ) + "</span>";
   }else{
    config.hintValue       =  '<br>Hints :<span class="green"> ' + config.currentWord.substring( 0, config.hints ) + 
                              "</span><br>Max Hints Shown";
   }
  showHide.checkStatus();
} 

/************** Button Submit Config  **********/
function submitConfigButton(){
  config.startRange = Number(showHide.getStartRange().value) -1;
  config.endRange   = Number(showHide.getEndRange().value) -1;
  updateFilteredList();
  showHide.checkStatus();
} 

function updateFilteredList(){
  filteredList    = new wordList();
  var rangeLength = config.endRange - config.startRange;
  for(i = 0 ; i < rangeLength; i++){
    filteredList.word[i]          = fullWordList.word[config.startRange + i];
    filteredList.translation1[i]  = fullWordList.translation1[config.startRange + i];
    filteredList.translation2[i]  = fullWordList.translation2[config.startRange + i];
    filteredList.synonym[i]       = fullWordList.synonym[config.startRange + i];
    filteredList.definition1[i]   = fullWordList.definition1[config.startRange + i];
    filteredList.definition2[i]   = fullWordList.definition2[config.startRange + i];
    filteredList.example[i]       = fullWordList.example[config.startRange + i];
    filteredList.example2[i]      = fullWordList.example2[config.startRange + i];
    filteredList.category[i]      = fullWordList.category[config.startRange + i];
    filteredList.type[i]          = fullWordList.type[config.startRange + i];
  }
  
  for(i = 0 ; i < (fullWordList.word.length - rangeLength) ; i++){
    filteredList.word.pop();
    filteredList.translation1.pop();
    filteredList.translation2.pop();
    filteredList.synonym.pop();
    filteredList.definition1.pop();
    filteredList.definition2.pop();
    filteredList.example.pop();
    filteredList.example2.pop();
    filteredList.category.pop();
    filteredList.type.pop();
  }  
}

/************** Show Hide Debug Div **********/
function btnShowVars(){
  if(config.debugDiv == "hide"){
    config.debugDiv = "show";
  }else if(config.debugDiv == "show"){
    config.debugDiv = "hide";
  }
  showHide.checkStatus();
}

/**************** Debug ******************/
function debugVal(){
  var debugConfiguration    = document.getElementById("debugConfiguration");
  debugConfiguration.innerHTML = 
    '<p>Nr : <span id="debugValues">' + config.nr + "</span></p>" + 
    '<p>Current Word : <span id="debugValues">' + config.currentWord + "</span></p>" + 
    '<p>input Answer : <span id="debugValues">' + showHide.getInput().value + "</span></p>" + 
    '<p>Given Word : <span id="debugValues">' + config.givenWord + "</span></p>" + 
    '<p>Wrong Answer : <span id="debugValues">' + config.wrongAnswer + "</span></p>" + 
    '<p>Status : <span id="debugValues">' + config.status + "</span></p>" + 
    '<p>Library Name : <span id="debugValues">' + config.libraryName + "</span></p>" + 
    '<p>Tries Left : <span id="debugValues">' + config.triesLeft + "</span></p>" + 
    '<p>Category Selected : <span id="debugValues">' + config.categorySelected + "</span></p>" + 
    '<p>Start Range : <span id="debugValues">' + config.startRange + "</span></p>" + 
    '<p>End Range : <span id="debugValues">' + config.endRange + "</span></p>" + 
    '<p>Swift : <span id="debugValues">' + config.swift + "</span></p>" + 
    '<p>Mode : <span id="debugValues">' + config.mode + "</span></p>" + 
    '<p>Correct : <span id="debugValues">' + config.correct + "</span></p>" + 
    '<p>Incorrect : <span id="debugValues">' + config.incorrect +  "</span></p>" +
    '<p>Debug div : <span id="debugValues">' + config.debugDiv +  "</span></p>" +
    '<p>Hints : <span id="debugValues">' + config.hints +  "</span></p>" +
    '<p>Filtered List length : <span id="debugValues">' + filteredList.word.length + "</span></p>";
}

/****** Enter Key ******/
document.getElementsByTagName("body")[0].addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
    if( config.status == "start" || config.status == "afterNext"){
      document.getElementById("buttonSubmitWord").click();              // Submit Button
    }else if(config.status == "default" || config.status == "confirm" || config.status == "finished"){
      document.getElementById("buttonNext").click();                    // Start/Next button
    }
  }
}); 

/************** Show / Hide tabs *************/
$(document).ready(function(){
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
});

