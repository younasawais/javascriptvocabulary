
document.onload = initialize();
var fullWordList; 
var filteredList;
var config;
var showHide;

function initialize(){
  fullWordList = new wordList(); 
  filteredList = new  wordList();
  config       = new configuration();
  config.setStatus("default");
  showHide = new showHideContent();
}



function showHideContent(){
  var buttonNext       = document.getElementById("buttonNext");
  var buttonSubmitWord = document.getElementById("buttonSubmitWord");
  var comment          = document.getElementById("comment");
  var nr               = document.getElementById("nr");
  var currentWord      = document.getElementById("currentWord");
  var status           = document.getElementById("status");
  var correct          = document.getElementById("correct");
  var incorrect        = document.getElementById("incorrect");
  var triesLeft        = document.getElementById("triesLeft");
  var totalWords       = document.getElementById("totalWords");
  var afterFilter      = document.getElementById("afterFilter");
  var libraryName      = document.getElementById("libraryName");
  var categorySelect   = document.getElementById("categorySelect");
  var swift            = document.getElementById("swift");
  var mode             = document.getElementById("mode");
  var submitConfig     = document.getElementById("submitConfig");
  switch (config.getStatus()) {
    case "default":
      /** HIDE **/
      currentWord.visibility = "hidden";
      buttonSubmitWord.visibility = "hidden";
      /** SHOW **/
      buttonNext.visibility = "visible";
      submitConfig.visibility = "visible";
      
      /** Value Next Button **/
      buttonNext.innerHTML = "START";
      comment.innerHTML = "Press Start";

        break;
    case "afterStart":
      /** HIDE **/
      buttonNext.visibility = "hidden";
      submitConfig.visibility = "hidden";
      /** SHOW **/
      buttonSubmitWord.visibility = "visible";
      currentWord.visibility = "visible";
      
      /** Value Next Button **/
      buttonNext.innerHTML = "(hidden)";
      comment.innerHTML = "Give the right answer";

        break;
    case "afterRightConfirm":
      /** HIDE **/
      buttonSubmitWord.visibility = "hidden";
      submitConfig.visibility = "hidden";
      
      
      /** SHOW **/
      currentWord.visibility = "visible";
      buttonNext.visibility = "visible";
      
      
      /** Value Next Button **/
      buttonNext.innerHTML = "NEXT";
      comment.innerHTML = "The right answer is TODO";
      

        break;
    case "afterNext":
      /** HIDE **/
      buttonNext.visibility = "hidden";
      submitConfig.visibility = "hidden";
      
      
      /** SHOW **/
      currentWord.visibility = "visible";
      buttonSubmitWord.visibility = "visible";
      
      
      /** Value Next Button **/
      buttonNext.innerHTML = "(hidden)";
      comment.innerHTML = "The right answer is TODO";
      

        break;
    case "afterFinished":
      /** HIDE **/
      currentWord.visibility = "hidden";
      buttonSubmitWord.visibility = "hidden";
      
      
      /** SHOW **/
      buttonNext.visibility = "visible";
      submitConfig.visibility = "visible";
      
      
      /** Value Next Button **/
      buttonNext.innerHTML = "RESTART";
      comment.innerHTML = "Restult: XX ";
    }
  /**  Update All values **/
   nr               = config.getNr();
 //TODO  currentWord      = config.getCur;
   status           = config.getStatus();
   correct          = config.getCorrect();
   incorrect        = config.getIncorrect();
   triesLeft        = config.getTriesLeft();
   totalWords       = count(fullWordList.word)
   afterFilter      = count(filteredList.word)
   libraryName      = config.getLibraryName();
//TODO   categorySelect   = config.getCategorySelect();
//TODO   swift            = config.getSwift();
//TODO   mode             = config.getMode();
}


function configuration(){
  this.nr;
  this.status; // default, after start, after confirm & no tries, after finished
  this.triesLeft ;
  this.categorySelecte;
  this.startRange;
  this.endRange;
  this.swift;
  this.mode;
  this.correct;
  this.incorrect;
  /******* Getters *******/
  this.getNr = function(){
    return this.nr;}
  this.getStatus = function(){
    return this.status;}  
  this.getTriesLeft = function(){
    return this.triesLeft;}  
  this.getCategorySelected = function(){
    return this.categorySelected;}  
  this.getStartRange = function(){
    return this.startRange;}  
  this.getEndRange = function(){
    return this.endRange; }  
  this.getSwift = function(){
    return this.swift;}  
  this.getMode = function(){
    return this.mode;}  
  this.getCorrect = function(){
    return this.correct;}  
  this.getIncorrect = function(){
    return this.incorrect;}

  /******* Setters *******/
  this.setNr = function(value){
    this.nr = value; }
  this.setStatus = function(value){
    this.status = value; }
  this.setTriesLeft = function(value){
    this.triesLeft = value; }
  this.setCategorySelected = function(value){
    this.categorySelected = value; }
  this.setStartRange = function(value){
    this.startRange = value; }
  this.setEndRange = function(value){
    this.endRange = value; }
  this.setSwift = function(value){
    this.swift = value; }
  this.setMode = function(value){
    this.mode = value; }
  this.setCorrect = function(value){
    this.correct = value; }
  this.setIncorrect = function(value){
    this.incorrect = value; }
  
}

function wordListFiltered(){
  this.word           = new Array("");
  this.translation1   = new Array("");
  this.translation2   = new Array("");
  this.synonym        = new Array("");
  this.definition1    = new Array("");
  this.definition2    = new Array("");
  this.example        = new Array("");
  this.category       = new Array("");
  this.type           = new Array("");
  this.reserve1       = new Array("");
  this.reserve2       = new Array("");  
  /******* Getters *******/
  this.getWord = function(){
    return this.word;}
}
/**************** reference code ******************/
  //filteredList.word = fullWordList.word.slice();
  //var newArray = oldArray.slice();
function test(){
  prompt("dasd");
}

/************** Show / Hide tabs *************/
$(document).ready(function(){
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
});