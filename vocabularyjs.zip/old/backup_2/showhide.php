/*Ignore this*/

  this.getInput = function(){
    return inputAnswer;
  }

  this.getButtonSubmit = function(){
    return buttonSubmitWord;
  }
  
 this.checkStatus = function(){
    switch (config.status) {
      case "default":
        /** HIDE **/
        givenWord.style.display = "none";
        buttonSubmitWord.style.display = "none";
        triesLeft.style.display = "none";
        correct.style.display = "none";
        incorrect.style.display = "none";
        /** SHOW **/
        buttonNext.style.display = "inline";
        submitConfig.style.display = "inline";

        /** Value Next Button **/
        buttonNext.innerHTML = "START";
        comment.innerHTML = "Press Start";

          break;
      case "afterStart":
        /** HIDE **/
        buttonNext.style.display = "none";
        submitConfig.style.display = "none";
        /** SHOW **/
        buttonSubmitWord.style.display = "inline";
        givenWord.style.display = "inline";
        triesLeft.style.display = "inline";
        correct.style.display = "inline";
        incorrect.style.display = "inline";

        /** Value Next Button **/
        buttonNext.innerHTML = "(hidden)";
        if(config.wrongAnswer === true){
           config.comment = config.comment;
        }else{
          comment.innerHTML = config.comment;
        }
          break;
      case "afterConfirm":
        /** HIDE **/
        buttonSubmitWord.style.display = "none";
        submitConfig.style.display = "none";

        /** SHOW **/
        givenWord.style.display = "inline";
        buttonNext.style.display = "inline";
        triesLeft.style.display = "inline";
        correct.style.display = "inline";
        incorrect.style.display = "inline";

        /** Value Next Button **/
        buttonNext.innerHTML = "NEXT";
        comment.innerHTML = config.comment;

          break;
      case "afterNext":
        /** HIDE **/
        buttonNext.style.display = "none";
        submitConfig.style.display = "none";

        /** SHOW **/
        givenWord.style.display = "inline";
        buttonSubmitWord.style.display = "inline";
        triesLeft.style.display = "inline";
        correct.style.display = "inline";
        incorrect.style.display = "inline";

        /** Value Next Button **/
        buttonNext.innerHTML = "(hidden)";
        comment.innerHTML = config.comment;

          break;
      case "afterFinished":
        /** HIDE **/
        givenWord.display = "none";
        buttonSubmitWord.display = "none";
        triesLeft.style.display = "none";
        correct.style.display = "none";
        incorrect.style.display = "none";

        /** SHOW **/
        buttonNext.style.display = "inline";
        submitConfig.style.display = "inline";

        /** Value Next Button **/
        buttonNext.innerHTML = "RESTART";
        comment.innerHTML = config.comment;
      }
      
/********  Update All values ********/
   nr.innerHTML               = (config.nr + 1) +" / "+filteredList.word.length;
   status.innerHTML           = config.status;
   correct.innerHTML          = config.correct;
   incorrect.innerHTML        = config.incorrect;
   triesLeft.innerHTML        = config.triesLeft;
   totalWords.innerHTML       = 'Total word : <span class="yellow">'+ fullWordList.word.length+"</span>";
   afterFilter.innerHTML      = 'After filter : <span class="yellow">'+ filteredList.word.length+"</span>";
   libraryName.innerHTML      = 'Library : <span class="yellow">' + config.libraryName+"</span>";
   givenWord.innerHTML        = config.givenWord;
   inputAnswer.value          = "";
   
  //TODO   categorySelect   = config.getCategorySelect();
  //TODO   swift            = config.getSwift();
  //TODO   mode             = config.getMode();
   debugVal();  //Show variables after every button press
  } // end checkStatus()





//Ignore this/*