
document.onload = initialize();
var fullWordList; 
var filteredList;
var config;
var showHide;

function initialize(){
  fullWordList    = new wordList(); 
  filteredList    = new wordList();
  config          = new configuration();
  config.status   = "default";
  showHide        = new showHideContent();
  showHide.checkStatus();
}

function startButton(){
  if(config.status == "default"){
    config.status         = "afterStart";
    config.nr             = 0;
  } else if(config.status == "afterConfirm"){
    config.status         = "afterNext";
    config.nr++; 
    config.triesLeft      = 3;
  }
  
  config.comment        = "Give in the right answer please!";
  config.currentWord    = filteredList.word[config.nr];
  showHide.getInput().focus();
  showHide.getInput().select();
  showHide.checkStatus();
  config.givenWord      = 
        filteredList.translation1[config.nr] + " : " + 
        filteredList.translation2[config.nr]; 
}

function submitWordButton(){
  showHide.getInput().value = showHide.getInput().value.toLowerCase();  //input to lowercase
  config.currentWord        = config.currentWord.toLowerCase();
  if(config.currentWord == showHide.getInput().value){ // Right answer
    config.correct++;
    config.status           = "afterConfirm";
    config.comment          = "Correct !";
  }else if(config.triesLeft === 1){   // Wrong answer & next try
    config.incorrect++;
    config.status           = "afterConfirm";
    config.comment          = "Correct answer is : " + config.currentWord + "!";
  }else{                              // Wrong answer & No tries left
    config.triesLeft--;
    config.wrongAnswer      = true;
    config.comment          = "Incorrect! You have " + config.triesLeft + " left!";
  }
  showHide.checkStatus();
}

function submitConfigButton(){
  
}



/**************** Debug ******************/
function debugVal(){
  var debugConfiguration    = document.getElementById("debugConfiguration");
  debugConfiguration.innerHTML = 
    '<p>Nr : <span id="debugValues">' + config.nr + "</span></p>" + 
    '<p>Current Word : <span id="debugValues">' + config.currentWord + "</span></p>" + 
    '<p>input Answer : <span id="debugValues">' + showHide.getInput().value + "</span></p>" + 
    '<p>Given Word : <span id="debugValues">' + config.givenWord + "</span></p>" + 
    '<p>Wrong Answer : <span id="debugValues">' + config.wrongAnswer + "</span></p>" + 
    '<p>Status : <span id="debugValues">' + config.status + "</span></p>" + 
    '<p>Library Name : <span id="debugValues">' + config.libraryName + "</span></p>" + 
    '<p>Tries Left : <span id="debugValues">' + config.triesLeft + "</span></p>" + 
    '<p>Category Selected : <span id="debugValues">' + config.categorySelected + "</span></p>" + 
    '<p>Start Range : <span id="debugValues">' + config.startRange + "</span></p>" + 
    '<p>End Range : <span id="debugValues">' + config.endRange + "</span></p>" + 
    '<p>Swift : <span id="debugValues">' + config.swift + "</span></p>" + 
    '<p>Mode : <span id="debugValues">' + config.mode + "</span></p>" + 
    '<p>Correct : <span id="debugValues">' + config.correct + "</span></p>" + 
    '<p>Incorrect : <span id="debugValues">' + config.incorrect +  "</span></p>";
}

/**** Enter Key ****/
document.getElementsByTagName("body")[0].addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
    if( config.status == "afterStart" || config.status == "afterNext"){
      document.getElementById("buttonSubmitWord").click();              // Submit Button
    }else if(config.status == "default" || config.status == "afterConfirm" || config.status == "afterFinished"){
      document.getElementById("buttonNext").click();                    // Start/Next button
    }
  }
}); 

/************** Show / Hide tabs *************/
$(document).ready(function(){
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
});

