<?php 
include 'includes/initialize.php';

?>