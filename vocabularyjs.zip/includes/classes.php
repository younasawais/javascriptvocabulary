<?php

/***************** GRAMMAR **********/
class visibility{
	public $submitWordButton		= "visible";
	public $submitRangeButton 		= "visible";
	public $submitCategoryButton 	= "visible";
	public $showHintButton 			= "visible";

	public $bar						= array('valueLine1'=>"",
											'valueLine2'=>"",
											'valueLine3'=>"",
											'colorLine1'=>"",
											'colorLine2'=>"",
											'colorLine3'=>"",
											'FontSizeLine1'=>"",
											'FontSizeLine2'=>"",
											'FontSizeLine3'=>"");
	public $startNextButton		 	= array('visibility'=>'','value'=>'');
	
	public function submitWordButton(){
		return 'style="visibility:'.$this->submitWordButton.'";';
	}
	public function submitRangeButton(){
		return 'style="visibility:'.$this->submitRangeButton.'";';
	}
	public function submitCategoryButton(){
		return 'style="visibility:'.$this->submitCategoryButton.'";';
	}
	public function showHintButton(){
		return 'style="visibility:'.$this->showHintButton.'";'; 
	}
	
	public function startNextButton(){
		if (isset($_SESSION["grammarStatus"])) {
			$arrayValue = array('style'=>('style="visibility:'.$this->startNextButton["visibility"].'";'));
			$arrayValue = array('value'=>$this->startNextButton['value']);
			return $arrayValue;
		}elseif ($_SESSION["multiStatus"]){
			switch ($_SESSION["multiStatus"]) {
				case 'stopped':
					echo '<input value="START" class="next" name="startNext" type="submit">';
					break;
				case 'finished':
					echo '<input value="RESTART" class="next" name="startNext" type="submit">';
					break;
				case 'next':
					echo '<input value="NEXT" class="next" name="startNext" type="submit">';
					break;
				case 'select':
					
					break;
				default:
					//'<input value="PROB" class="next" name="startNext" type="submit">';
				break;
			}
		}

	}
	public function showBar(){
		$arrayValue = array(
				'valueLine1'=>$this->bar['valueLine1'],
				'valueLine2'=>$this->bar['valueLine2'],
				'valueLine3'=>$this->bar['valueLine3'],
				'colorLine1'=>'style="color:'.$this->bar['colorLine1'].'";',
				'colorLine2'=>'style="color:'.$this->bar['colorLine2'].'";',
				'colorLine3'=>'style="color:'.$this->bar['colorLine3'].'";',
				'FontSizeLine1'=>'style="font-size:'.$this->bar['FontSizeLine1'].'px";',
				'FontSizeLine2'=>'style="font-size:'.$this->bar['FontSizeLine2'].'px";',
				'FontSizeLine3'=>'style="font-size:'.$this->bar['FontSizeLine3'].'px";'
		);
		return $arrayValue;
	}
}

class wordList{
	public $word 					= array();
	public $translate1 		= array();
	public $translate2		= array();
	public $synonym 			= array();
	public $definition	 	= array();
	public $definition2	 	= array();
	public $example 			= array();
	public $example2 			= array();
	public $category 			= array();
	public $type		 			= array();
	public $categoryList	= array();
	public function totalWords(){		// Return total amount of words
		return count($word);
	}
	public function totalWordsFiltered(){		// Return total amount of words
		if (isset($_SESSION["wordListFiltered"]/*->totalWords()*/)) {
			return $_SESSION["wordListFiltered"]->totalWords();
		}else{
			return count($word);
		}
	}
	
	public function initiateCyclus(){ // Initiate all objects visibilities whenever submit button pressed
		
	/************** MULTIPLE CHOICE ****************** TODO */
		if (isset($_SESSION["multiStatus"])) {
			if ($_SESSION["multiStatus"] == 'stopped'){
				$_SESSION['visibility']->submitWordButton 				= "visible";
				$_SESSION['visibility']->submitRangeButton				= "visible";
				$_SESSION['visibility']->submitCategoryButton			= "visible";
				$_SESSION['visibility']->showHintButton					= "visible";
				$_SESSION['visibility']->startNextButton['visibility']	= "visible";
				$_SESSION['visibility']->startNextButton['value']		= "visible";
			}elseif ($_SESSION["multiStatus"] == 'submitWord'){
				$_SESSION['visibility']->submitWordButton 				= "visible";
				$_SESSION['visibility']->submitRangeButton				= "hidden";
				$_SESSION['visibility']->submitCategoryButton			= "hidden";
				$_SESSION['visibility']->showHintButton						= "visible";
				$_SESSION['visibility']->startNextButton['visibility']	= "hidden";
				$_SESSION['visibility']->startNextButton['value']		= "";
			}elseif ($_SESSION["multiStatus"] == 'nextWord'){
				$_SESSION['visibility']->submitWordButton 				= "hidden";
				$_SESSION['visibility']->submitRangeButton				= "hidden";
				$_SESSION['visibility']->submitCategoryButton			= "hidden";
				$_SESSION['visibility']->showHintButton					= "hidden";
				$_SESSION['visibility']->startNextButton['visibility']	= "visible";
				$_SESSION['visibility']->startNextButton['value']		= "NEXT";
			}elseif ($_SESSION["multiStatus"] == 'finished'){
				$_SESSION['visibility']->submitWordButton 				= "hidden";
				$_SESSION['visibility']->submitRangeButton				= "visible";
				$_SESSION['visibility']->submitCategoryButton			= "visible";
				$_SESSION['visibility']->showHintButton					= "hidden";
				$_SESSION['visibility']->startNextButton['visibility']	= "visible";
				$_SESSION['visibility']->startNextButton['value']		= "RESTART";
			}
		}
	}
}

class wordListFiltered{
	public $word 				= array();
	public $translate1 			= array();
	public $translate2			= array();
	public $synonym 			= array();
	public $definition 			= array();
	public $example 			= array();
	public $buttonValues		= array();
	public $categorySelected	= "ALL";
	public $modeSelected		= "wordToTrans";
	public $selectionsSelected	= 8;
	public $startRange			= 0;
	public $endRange			= 0;
	public $totalRight 			= 0;
	public $totalWrong 			= 0;
	public $triesLeft 			= 3;
	public $hint 				= 0;
	
	
	function multiSelections(){
		if ($_SESSION["multiStatus"] == 'select' ||$_SESSION["multiStatus"] == 'next' || $_SESSION["multiStatus"] == 'finished') {
			for ($i = 0; $i < $this->selectionsSelected; $i++) {
				echo '<input value="'.$this->buttonValues[$i].'" class="answer" name="answer'.($i+1).'" type="submit">';
			}
		}else{
			for ($i = 0; $i < $this->selectionsSelected; $i++) {
				echo '<input value="ANSWER '.($i+1).'" class="answer" name="answer'.($i+1).'" type="submit">';
			}
		}

	}
	
	function setFilteredList(){	
		$startRange = $this->startRange;
		$endRange   = $this->endRange;
		$category   = $this->categorySelected;

		for ($i = ($startRange-1); $i <= ($endRange-1); $i++) {
			if($category == "ALL"){
				array_push($this->word, 		$_SESSION["wordList"]->word[$i]);
				array_push($this->translate1,	$_SESSION["wordList"]->translate1[$i]);
				array_push($this->translate2, 	$_SESSION["wordList"]->translate2[$i]);
				array_push($this->synonym, 		$_SESSION["wordList"]->synonym[$i]);
				array_push($this->example,	 	$_SESSION["wordList"]->example[$i]);
				array_push($this->definition, 	$_SESSION["wordList"]->definition[$i]);
			}else if($_SESSION["wordList"]->category[$i] == $category) {
				array_push($this->word, 		$_SESSION["wordList"]->word[$i]);
				array_push($this->translate1, 	$_SESSION["wordList"]->translate1[$i]);
				array_push($this->translate2,	$_SESSION["wordList"]->translate2[$i]);
				array_push($this->synonym,		$_SESSION["wordList"]->synonym[$i]);
				array_push($this->example,	 	$_SESSION["wordList"]->example[$i]);
				array_push($this->definition,	$_SESSION["wordList"]->definition[$i]);
			}
		}
	}
	
	function totalWords(){
		return count($this->word);
	}
	
	function currentWord(){
		if ($_SESSION["grammarStatus"]=="stopped" || $_SESSION["grammarStatus"]=="finished") {
			return "(PRESS START)";
		}else{
			return $this->word[$_SESSION["currentNumber"]];
		}
	}
		
	function translations(){
		if (isset($_SESSION["grammarStatus"])) {
			if ($_SESSION["grammarStatus"]=="stopped" || $_SESSION["grammarStatus"]=="finished") {
				return "(PRESS START)";
			}else{
				return $this->translate1[$_SESSION["currentNumber"]]. " / " .$this->translate2[$_SESSION["currentNumber"]];
			}
		}elseif (isset($_SESSION["multiStatus"])){
			if ($_SESSION["multiStatus"]=="stopped" || $_SESSION["multiStatus"]=="finished") {
				return "(PRESS START)";
			}else{
				switch ($this->modeSelected) {
					case "wordToTrans":
						return $this->word[$_SESSION["currentNumber"]];
						break;
					case "transToWord":
						return $this->translate1[$_SESSION["currentNumber"]] . " / " . $this->translate2[$_SESSION["currentNumber"]] ;
						break;
					case "defToWord":
						return $this->definition[$_SESSION["currentNumber"]];
						break;
					case "wordToDef":
						return $this->word[$_SESSION["currentNumber"]];
						break;
					default:
						echo "not in the list";
						break;
				}
				//return $this->translate1[$_SESSION["currentNumber"]]. " / " .$this->translate2[$_SESSION["currentNumber"]];
			}
		}
	}
	
	function totalRight(){
		if (isset($_SESSION["grammarStatus"])) {
			if ($_SESSION["grammarStatus"]=="stopped") {
				return "/";
			}else {
				return $this->totalRight;
			}
		}elseif (isset($_SESSION["multiStatus"])){
			if ($_SESSION["multiStatus"]=="stopped") {
				return "/";
			}else {
				return $this->totalRight;
			}
		}
	}
	
	function totalWrong(){
		if (isset($_SESSION["grammarStatus"])) {
			if ($_SESSION["grammarStatus"]=="stopped") {
				return "/";
			}else {
				return $this->totalWrong;
			}
		}elseif (isset($_SESSION["multiStatus"])){
			if ($_SESSION["multiStatus"]=="stopped") {
				return "/";
			}else {
				return $this->totalWrong;
			}
		}
	}
	
	function triesLeft(){
		if ($_SESSION["grammarStatus"]=="stopped") {
			return "/";
		}else{
			return $this->triesLeft;
		}
	}
	
	function hints($submitted){
		$lengthWord = strlen($this->currentWord());
		$astrix		= "";
		

		if ($submitted=="add") {
			if ($this->hint < ($lengthWord/1.4)) {
				$this->hint++;
			}
			
			$showChars  = substr($this->currentWord(), 0, $this->hint);
			for ($i = $this->hint; $i <= ($lengthWord-$this->hint); $i++) {
				$astrix = $astrix . '*';
			}
			return ($showChars.$astrix);
			
		}else if ($submitted=="notAdd") {
			$showChars  = substr($this->currentWord(), 0, $this->hint);
			for ($i = $this->hint; $i < ($lengthWord-$this->hint); $i++) {
				$astrix = $astrix . '*';
			}
			return ($showChars.$astrix);
		}
	}
}



class user{
	public $username;
	public $password;
	public $category;
}

/***************** MULTIPLE CHOICE **********/
class general{

	public function startNext() {
		if (isset ( $_POST['startNext'] ) && $_SESSION["multiStatus"] == 'stopped') { 	 	 		// after button (( START ))
			$_SESSION["multiStatus"] = 'select';
			$_SESSION["currentNumber"]++;
			$_SESSION['wordListFiltered']->setFilteredList (); 										// setup filtered list
			$_SESSION["wordListFiltered"]->buttonValues = $this->buttonValues();
		}else if (isset ( $_POST['startNext'] ) && $_SESSION["multiStatus"] == 'next'){				// after button (( NEXT ))
			if ($_SESSION["wordList"]->totalWordsFiltered() > ($_SESSION["currentNumber"]+1)) {		// Last word?
				$_SESSION["currentNumber"]++;
				$_SESSION["wordListFiltered"]->buttonValues = $this->buttonValues();
				$_SESSION["multiStatus"]	 				= 'select';
				$_SESSION['visibility']->bar ['valueLine1'] = "SELECT FROM ABOVE PLEASE";
			}else {
				$_SESSION["multiStatus"]	 				= 'finished';
				$_SESSION['visibility']->bar ['valueLine1'] = "RIGHT: ".$_SESSION["wordListFiltered"]->totalRight.
															  "/ WRONG: ".$_SESSION["wordListFiltered"]->totalWrong;
			}
			

		}else if (isset ( $_POST['startNext'] ) && $_SESSION["multiStatus"] == 'finished'){			// after button (( FINISHED ))
			$_SESSION["multiStatus"] = 'select';
			$_SESSION["currentNumber"] = 0;
			unset($_SESSION['wordListFiltered']);
			$_SESSION["wordListFiltered"]								= new wordListFiltered();
			$_SESSION['wordListFiltered']->setFilteredList (); 										// setup filtered list
			$_SESSION["wordListFiltered"]->buttonValues = $this->buttonValues();
			$_SESSION["wordListFiltered"]->totalRight 	= 0;
			$_SESSION["wordListFiltered"]->totalWrong 	= 0;
		}
	} 
	
	public function buttonValues(){
		$mode = $_SESSION['wordListFiltered']->modeSelected;
		$buttonValues = array();
		
		$debug = $this->answerPosition();
		if($mode=="wordToTrans"){		// Get random translations 
			foreach ($this->randomGenerator() as $dig) {
				array_push($buttonValues,$_SESSION["wordList"]->translate1[$dig]); 
			}
			$buttonValues[$this->answerPosition()] = $_SESSION["wordListFiltered"]->translate1[$_SESSION["currentNumber"]];
		}elseif ($mode=="transToWord"){	// Get random words
			foreach ($this->randomGenerator() as $dig) {
				array_push($buttonValues,$_SESSION["wordList"]->word[$dig]);
			}
			$buttonValues[$this->answerPosition()] = $_SESSION["wordListFiltered"]->word[$_SESSION["currentNumber"]];
		}elseif ($mode=="defToWord"){	// Get random words
			foreach ($this->randomGenerator() as $dig) {
				array_push($buttonValues,$_SESSION["wordList"]->word[$dig]);
			}
			$buttonValues[$this->answerPosition()] = $_SESSION["wordListFiltered"]->word[$_SESSION["currentNumber"]];
		}elseif ($mode=="wordToDef"){	// Get random definitions
			foreach ($this->randomGenerator() as $dig) {
				array_push($this->$buttonValues,$_SESSION["wordList"]->definition[$dig]);
			}
			$buttonValues[answerPosition()] = $_SESSION["wordListFiltered"]->definition[$_SESSION["currentNumber"]];
		}
		return $buttonValues;
	}
	
	public function answerPosition(){
		//$_SESSION["currentNumber"];
		$max = $_SESSION['wordListFiltered']->selectionsSelected - 1;
		return $position = rand(1,$max);
	}
	
	public function submitAnswer() {
		$debug = "debug";	// temporary debugging
		for ($i = 0; $i < ($_SESSION['wordListFiltered']->selectionsSelected+1); $i++) {
			if (isset ( $_POST["answer$i"]) && ($_SESSION["multiStatus"]=="select")) {
				switch ($_SESSION["wordListFiltered"]->modeSelected) {
					case "wordToTrans":
						if ($_POST["answer$i"]==$_SESSION['wordListFiltered']->translate1[$_SESSION["currentNumber"]]) {
							$_SESSION["wordListFiltered"]->totalRight++;
							$_SESSION['visibility']->bar ['valueLine1'] = "RIGHT!";
						}else{
							$_SESSION["wordListFiltered"]->totalWrong++;
							$_SESSION['visibility']->bar ['valueLine1'] = "WRONG! RIGHT ANSWER: ".$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]];
						}
						break;
					case "transToWord":
						if ($_POST["answer$i"]==$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]]) {
							$_SESSION["wordListFiltered"]->totalRight++;
							$_SESSION['visibility']->bar ['valueLine1'] = "RIGHT!";
						}else{
							$_SESSION["wordListFiltered"]->totalWrong++;
							$_SESSION['visibility']->bar ['valueLine1'] = "WRONG! RIGHT ANSWER: ".$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]];
						}
						break;
					case "defToWord":
						if ($_POST["answer$i"]==$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]]) {
							$_SESSION["wordListFiltered"]->totalRight++;
							$_SESSION['visibility']->bar ['valueLine1'] = "RIGHT!";
						}else{
							$_SESSION["wordListFiltered"]->totalWrong++;
							$_SESSION['visibility']->bar ['valueLine1'] = "WRONG! RIGHT ANSWER: ".$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]];
						}
						break;
					case "wordToDef":
						if ($_POST["answer$i"]==$_SESSION['wordListFiltered']->definition[$_SESSION["currentNumber"]]) {
							$_SESSION["wordListFiltered"]->totalRight++;
							$_SESSION['visibility']->bar ['valueLine1'] = "RIGHT!";
						}else{
							$_SESSION["wordListFiltered"]->totalWrong++;
							$_SESSION['visibility']->bar ['valueLine1'] = "WRONG! RIGHT ANSWER: ".$_SESSION['wordListFiltered']->word[$_SESSION["currentNumber"]];
						}
						break;
					default:
						echo "not in the list";
						break;
				}
				$_SESSION["multiStatus"] = 'next';
			}
		}

	}
	
	public function submitRange() {
		if (isset ( $_POST["submitRange"]) && ($_SESSION["multiStatus"]=="stopped"||$_SESSION["multiStatus"] == "finished")) {
			if (isset ( $_POST["startRange"] ) && isset ( $_POST["endRange"] ) && ! empty ( $_POST["startRange"] ) && ! empty ( $_POST["endRange"] )) {
				if ($_POST["startRange"] < $_POST["endRange"] && $_POST["endRange"] < ($_SESSION['words'] + 1)) {
 					$_SESSION['wordListFiltered']->startRange = $_POST["startRange"];
 					$_SESSION['wordListFiltered']->endRange = $_POST["endRange"];
// 					$_SESSION['visibility']->bar ['valueLine1'] = "";
				}else{
// 					$_SESSION['visibility']->bar ['valueLine1'] = "CHECK RANGES PLEASE!";	TODO
				}
			} else if($_POST["startRange"]){
				//$_SESSION['visibility']->bar ['valueLine1'] = "Check ranges please";
			}
		}
	} 
	
	public function randomGenerator(){		// unique random numbers between 0 & max words
		$max = $_SESSION['words']-1;
		$min = 0;
		$random;
		$randomNumbers = array();
		
		for ($i = 0; $i < $_SESSION['wordListFiltered']->selectionsSelected; $i++) {
			$random = rand($min, $max);
			if (in_array($random, $randomNumbers)) {
				$i--;
			}else{
				array_push($randomNumbers,$random);
			}
		}
		return $randomNumbers;
	}
	
	public function checkWordListAvailable() {
		if (isset ( $_SESSION['wordList'] )) {
			$_SESSION['grammarStarted'] 	= 1;
			$_SESSION['multiStarted'] 		= 1;
		} else {
			header ( 'Location: index.php' ); // redirect to dashboard
		}
	} 
	
	public function categorySelection() {
		//$temp = $_SESSION['wordListFiltered']->categorySelected;
		//echo "<option value='$temp'>{$temp}</option>"; // TODO 
		foreach ( $_SESSION['wordList']->categoryList as $i ) { // go through categoryList
			echo "<option value='$i'>{$i}</option>"; // echo every single category
		}
	}
	
	public function submitCategory() {
		if (isset ( $_POST['submitCategory'])&& ($_SESSION["multiStatus"]=="stopped"||$_SESSION["multiStatus"] == "finished")) {									// If category submitted
			$_SESSION['visibility']->bar ['valueLine1'] = "CATEGORY '{$_POST['dropdown']}' APPLIED";
			return $_SESSION['wordListFiltered']->categorySelected = $_POST['dropdown'];
		}else if(isset($_SESSION['wordListFiltered']->categorySelected)){					// If category already set
			return $_SESSION['wordListFiltered']->categorySelected;
		}else{
			return $_SESSION['wordListFiltered']->categorySelected = "ALL";
		}
	} 
	
	public function submitMode() {
		if (isset ( $_POST['submitMode'] ) && ($_SESSION["multiStatus"]=="stopped"||$_SESSION["multiStatus"] == "finished")) {									// If category submitted
			$_SESSION['wordListFiltered']->modeSelected = $_POST['dropdownMode'];
			$_SESSION['visibility']->bar ['valueLine1'] = "MODE '{$_POST['dropdownMode']}' APPLIED";
		}
	} 
	
	public function submitSelections() {
		if (isset ( $_POST['submitSelections'] ) && ($_SESSION["multiStatus"]=="stopped"||$_SESSION["multiStatus"] == "finished")) {									// If category submitted
			$_SESSION['wordListFiltered']->selectionsSelected = $_POST['dropdownSelections'];
			$_SESSION['visibility']->bar ['valueLine1'] = "Selections '{$_POST['dropdownSelections']}' APPLIED";
		}
	}

	public function goback(){
		if (isset ( $_POST['exit'] )) {
			$_SESSION['wordListFiltered']->startRange 	= 0;
			$_SESSION['wordListFiltered']->endRange 	= $_SESSION['words'];
			unset ( $_SESSION['multiStatus'] );
			unset ( $_SESSION['multiStarted'] );
			$_SESSION['visibility']->bar ['valueLine1'] = "";
			header ( 'Location: index.php' ); // redirect to dashboard
		}
	}
	
	public function restart (){
		if (isset ( $_POST['restart'] )) {
		if (isset ( $_POST['exit'] )) {
			$_SESSION['wordListFiltered']->startRange 	= 0;
			$_SESSION['wordListFiltered']->endRange 	= $_SESSION['words'];
			$_SESSION["multiStatus"] = 'stopped';
			$_SESSION['visibility']->bar ['valueLine1'] = "";
			header ( 'Location: index.php' ); // redirect to dashboard
		}
			// 			$_SESSION['visibility']->bar ['valueLine3'] = "PRESS RESTART OR CHANGE RANGE & CATEGORY";  TODO
			// 			$_SESSION["grammarStatus"] = 'stopped';
			// 			$_SESSION["currentNumber"] = -1;
			// 			$_SESSION['visibility']->bar ['valueLine1'] = "";
			// 			$_SESSION['visibility']->bar ['valueLine2'] = "";
			// 			$_SESSION['visibility']->bar ['valueLine3'] = "PRESS RESTART OR CHANGE RANGE & CATEGORY";
			// 			$_SESSION['wordListFiltered']->startRange 	= 0;
			// 			$_SESSION['wordListFiltered']->endRange		= $_SESSION['words'];
			// 			unset ( $_SESSION['grammarStarted'] );
			// 			$_SESSION["grammarStatus"] = 'stopped';
		}
	}
	
}

?>