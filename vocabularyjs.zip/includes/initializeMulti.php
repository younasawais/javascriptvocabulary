<?php 

if (!isset($_SESSION['multiStarted'])) {
	if (!($_SESSION['logStatus'] == "loggedin")) {
		header('Location: login.php');			// redirect to dashboard;
	}
	
	if(!isset($_SESSION['library'])){
		$_SESSION['library'] = "Import/Select library";
	}
	
	if (isset($_SESSION['wordList'])) {
		$wordlistAvailable = "yes";
	}else{
		$wordlistAvailable = "no";
	}
	
	$_SESSION["multiStatus"] 						= 'stopped';
	$_SESSION["currentNumber"]						= -1;
	$_SESSION["general"]							= new general(); 
	$_SESSION["wordListFiltered"]					= new wordListFiltered();
	$_SESSION["visibility"] 						= new visibility();
	$_SESSION['wordListFiltered']->startRange	 	= 1;
	$_SESSION['wordListFiltered']->endRange		 	= $_SESSION['words'];
}

?>