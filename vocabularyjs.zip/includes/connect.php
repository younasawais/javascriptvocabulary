<?php 
function checkLogin($user, $pass) {
	$sql =  "SELECT * FROM `users` WHERE name='{$user}' AND password='{$pass}'";
	        // SELECT * FROM `users` WHERE name='awais' AND password='awais'
	return sqlQuery($sql);
}

function sqlQuery($sql){
	$dbhost = 'localhost';
	$dbuser = 'younasaw_quiz';
	$dbpass = 'younasaw_quiz';
	$db     = 'younasaw_quiz';
	
	$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db);
	if(!$conn )	{die('Could not connect: ' . mysqli_error());}
	//mysql_select_db( 'younasaw_visitor' );
	$result= mysqli_query($conn, $sql);
	if(! $result)
	{ die('Could not get data: ' . mysqli_error());}
	//	echo "succesfull query";
	mysqli_close($conn);
	//return $result;
	return mysqli_fetch_array($result);
}

?>