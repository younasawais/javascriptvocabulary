<?php

if (!isset($_SESSION['grammarStarted'])) {
	if (!($_SESSION['logStatus'] == "loggedin")) {
		header('Location: login.php');			// redirect to dashboard;
	}
	
	if(!isset($_SESSION['library'])){
		$_SESSION['library'] = "Import/Select library";
	}
	
	if (isset($_SESSION['wordList'])) {
		$wordlistAvailable = "yes";
	}else{
		$wordlistAvailable = "no";
	}
	
	$_SESSION["grammarStatus"] 						= 'stopped';
	$_SESSION["currentNumber"]						= -1;
	//	$_SESSION["showHint"] 							= 0;
	$_SESSION["triesLeft"] 							= 3;
	$_SESSION["highlight"] 							= "";
	$_SESSION["wordListFiltered"]					= new wordListFiltered();
	$_SESSION["visibility"] 						= new visibility();
	$_SESSION['wordListFiltered']->startRange	 	= 1;
	$_SESSION['wordListFiltered']->endRange		 	= $_SESSION['words'];
}

?>