<?php 
session_start();

if (!($_SESSION['logStatus'] == "loggedin")) {
	header('Location: login.php');			// redirect to dashboard;
}

if(!isset($_SESSION['library'])){
	$_SESSION['library'] = "Import/Select library";
}

if (isset($_SESSION['wordList'])) {
	$wordlistAvailable = "yes";
}else{
	$wordlistAvailable = "no";
}
?>